def lambda_handler(event , context):
    print("hola mundo soy una lambda desde Terraform - lambda lab")
    return "hola mundo soy una lambda desde Terraform - lambda lab"